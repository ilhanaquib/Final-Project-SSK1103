import java.awt.event.*;
import java.lang.System.Logger.Level;
import java.util.Timer;
import java.awt.*;
import javax.swing.*;

class picpuzzle2 extends JFrame implements ActionListener{
 
// declaring variables
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b14,b18,b19,b22,b23,b24,b25,b26,b51,b52,b53,b54,b55,b56,b57,b58,b59,sample,starB,bEasy,bMedium,bHard;
Icon star;

// *CHANGE IMAGE PATH BEFORE RUNNING!*

// icon image (top)
Icon ic0=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\icon\\puzzle1 3x3 icon.jpg");
Icon ic10=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\icon\\puzzle2 3x3 icon.jpg");
Icon ic20=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\icon\\puzzle3 3x3 icon.jpg");
Icon ic30= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\icon\\puzzle4 3x3 icon.jpg");

// sample image (right)
Icon samicon1=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\sample\\puzzle1 sample.jpg");
Icon samicon2=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\sample\\puzzle2 sample.jpg");
Icon samicon3=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\sample\\puzzle3 sample.jpg");
Icon samicon4=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\sample\\puzzle4 sample.jpg");

// puzzle 1 image (3x3)
Icon ic1=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//1
Icon ic2=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\5.jpg");//5
Icon ic3=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\2.jpg");//2
Icon ic4=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\7.jpg");//7
Icon ic5=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\4.jpg");//4
Icon ic6=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\6.jpg");//6
Icon ic7=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\8.jpg");//8
Icon ic8=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\9.jpg");//9
Icon ic9=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\3.jpg");//3

// puzzle 2 image 3x3
Icon ic11=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\1.jpg");
Icon ic12=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\5.jpg");
Icon ic13=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\2.jpg");
Icon ic14=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\7.jpg");
Icon ic15=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\4.jpg");
Icon ic16=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\6.jpg");
Icon ic17=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\8.jpg");
Icon ic18=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\9.jpg");
Icon ic19=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle2\\puzzle2 5x5\\3.jpg");

// puzzle 3 image 3x3
Icon ic21=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\1.jpg");
Icon ic22=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\5.jpg");
Icon ic23=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\2.jpg");
Icon ic24=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\7.jpg");
Icon ic25=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\4.jpg");
Icon ic26=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\6.jpg");
Icon ic27=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\8.jpg");
Icon ic28=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\9.jpg");
Icon ic29=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle3\\puzzle3 5x5\\3.jpg");

// puzzle 4 image 3x3
Icon ic31= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\1.jpg");
Icon ic32= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\5.jpg");
Icon ic33= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\2.jpg");
Icon ic34= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\7.jpg");
Icon ic35= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\4.jpg");
Icon ic36= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\6.jpg");
Icon ic37= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\8.jpg");
Icon ic38= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\9.jpg");
Icon ic39= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle4\\puzzle4 5x5\\3.jpg");

//puzzle 1 image 4x4
Icon ic41= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\10.jpg");//1
Icon ic42= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\15.jpg");//5
Icon ic43= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\13.jpg");//8
Icon ic44= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\16.jpg");//10
Icon ic45= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\12.jpg");//2
Icon ic46= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\14.jpg");//7
Icon ic47= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\11.jpg");//3

//5x5
Icon ic48= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//6
Icon ic49= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//4
Icon ic51= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//9
Icon ic52= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//15
Icon ic53= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//13
Icon ic54= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//11
Icon ic55= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//14
Icon ic56= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//12
Icon ic57= new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\puzzle images\\puzzle1\\puzzle1 5x5\\1.jpg");//16

 


// puzzle 5 (5x5)


Icon black=new ImageIcon("D:\\upm\\sem2\\oop\\PicPuzzle\\picpuzzle\\Black.png");

picpuzzle2(){

// form title
super("Pic Puzzle");

// creating each grid (3x3)
b1=new JButton(ic1);
b1.setBounds(10,80,100,100);
b2=new JButton(ic2);
b2.setBounds(110,80,100,100);
b3=new JButton(ic3);
b3.setBounds(210,80,100,100);
b4=new JButton(ic4);
b4.setBounds(10,180,100,100);
b5=new JButton(ic5);
b5.setBounds(110,180,100,100);
b6=new JButton(ic6);
b6.setBounds(210,180,100,100);
b7=new JButton(ic7);
b7.setBounds(10,280,100,100);
b8=new JButton(ic8);
b8.setBounds(110,280,100,100);
b9=new JButton(ic9);
b9.setBounds(210,280,100,100);

// creating each grid (4x4)
b14=new JButton(black);
b14.setBounds(310,80,100,100);
b14.setVisible(false);
b18=new JButton(black);
b18.setBounds(310,180,100,100);
b18.setVisible(false);
b22=new JButton(black);
b22.setBounds(310,280,100,100);
b22.setVisible(false);
b23=new JButton(black);
b23.setBounds(10,380,100,100);
b23.setVisible(false);
b24=new JButton(black);
b24.setBounds(110,380,100,100);
b24.setVisible(false);
b25=new JButton(black);
b25.setBounds(210,380,100,100);
b25.setVisible(false);
b26=new JButton(black);
b26.setBounds(310,380,100,100);
b26.setVisible(false);

// creating grid (5x5)
b51=new JButton(black);
b51.setBounds(410,80,100,100);
b51.setVisible(false);
b52=new JButton(black);
b52.setBounds(410,180,100,100);
b52.setVisible(false);
b53=new JButton(black);
b53.setBounds(410,280,100,100);
b53.setVisible(false);
b54=new JButton(black);
b54.setBounds(410,380,100,100);
b54.setVisible(false);
b55=new JButton(black);
b55.setBounds(10,480,100,100);
b55.setVisible(false);
b56=new JButton(black);
b56.setBounds(110,480,100,100);
b56.setVisible(false);
b57=new JButton(black);
b57.setBounds(210,480,100,100);
b57.setVisible(false);
b58=new JButton(black);
b58.setBounds(310,480,100,100);
b58.setVisible(false);
b59=new JButton(black);
b59.setBounds(410,480,100,100);
b59.setVisible(false);

// sample button (right big image)
sample=new JButton(samicon1);
sample.setBounds(620,100,200,200);

// difficulty button
bEasy = new JButton("Easy");
bEasy.setBounds(650, 370, 100, 40);
bMedium = new JButton("Medium");
bMedium.setBounds(650, 420, 100, 40);
bHard = new JButton("Hard");
bHard.setBounds(650, 470, 100, 40);

// labels
JLabel l1=new JLabel("Solution :");
l1.setBounds(550,200,70,20);
JLabel l2=new JLabel("NOTE:: Only this image can be moved => ");
l2.setBounds(80,15,500,20);
JLabel l3=new JLabel("click the solution image to move to the next puzzle");
l3.setBounds(550,320,300,20);
l3.setForeground(Color.red);


// button for icon
starB=new JButton(ic0);
starB.setBounds(330,5,50,50);
star=b9.getIcon();

// adding button / grid and action listener
add(b1);add(b2);add(b3);add(b4);add(b5);add(b6);add(b7);add(b8);add(b9);add(sample);add(l1);add(l2);add(starB);add(l3);
add(b14);add(b18);add(b22);add(b23);add(b24);add(b25);add(b26);
add(b51);add(b52);add(b53);add(b54);add(b55);add(b56);add(b57);add(b58);add(b59);
add(bEasy);add(bMedium);add(bHard);
b1.addActionListener(this); b2.addActionListener(this); b3.addActionListener(this); b4.addActionListener(this); b5.addActionListener(this); b6.addActionListener(this);
b7.addActionListener(this); b8.addActionListener(this); b9.addActionListener(this); 
b14.addActionListener(this); b18.addActionListener(this);b22.addActionListener(this); 
b23.addActionListener(this); b24.addActionListener(this); b25.addActionListener(this); b26.addActionListener(this);
//b14.setEnabled(false);b18.setEnabbled(false);b22.setEnabled(false);b23.setEnabled(false);b24.setEnabled(false);b25.setEnabled(false);b26.setEnabled(false);
bEasy.addActionListener(this);bMedium.addActionListener(this);bHard.addActionListener(this);

sample.addActionListener(this);
setLayout(null);
setSize(1000,660);
setVisible(true);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

// moving the images / puzzle
public void actionPerformed(ActionEvent e){


// move image/puzzle 


if(e.getSource()==b1){
    Icon s1=b1.getIcon();
      if(b2.getIcon()==star){
        b2.setIcon(s1);
        b1.setIcon(star);
      } else if(b4.getIcon()==star){
                    b4.setIcon(s1);
                    b1.setIcon(star);
                   }
  }//end of if

if(e.getSource()==b2){
    Icon s1=b2.getIcon();
      if(b1.getIcon()==star){
        b1.setIcon(s1);
        b2.setIcon(star);
      } else if(b5.getIcon()==star){
                    b5.setIcon(s1);
                    b2.setIcon(star);
                   }
         else if(b3.getIcon()==star){
                    b3.setIcon(s1);
                    b2.setIcon(star);
                   }
  }//end of if

if(e.getSource()==b3){
    Icon s1=b3.getIcon();
      if(b2.getIcon()==star){
        b2.setIcon(s1);
        b3.setIcon(star);
      } else if(b6.getIcon()==star){
                    b6.setIcon(s1);
                    b3.setIcon(star);
                   }
        else if(b14.getIcon()==star){
                    b14.setIcon(s1);
                    b3.setIcon(star);
                   }
  }//end of if

if(e.getSource()==b4){
    Icon s1=b4.getIcon();
      if(b1.getIcon()==star){
        b1.setIcon(s1);
        b4.setIcon(star);
      } else if(b5.getIcon()==star){
                    b5.setIcon(s1);
                    b4.setIcon(star);
                   }
         else if(b7.getIcon()==star){
                    b7.setIcon(s1);
                    b4.setIcon(star);
                   }
  }//end of if

if(e.getSource()==b5){
    Icon s1=b5.getIcon();
      if(b2.getIcon()==star){
        b2.setIcon(s1);
        b5.setIcon(star);
      } else if(b4.getIcon()==star){
                    b4.setIcon(s1);
                    b5.setIcon(star);
                   }
         else if(b6.getIcon()==star){
                    b6.setIcon(s1);
                    b5.setIcon(star);
                   }
          else if(b8.getIcon()==star){
                    b8.setIcon(s1);
                    b5.setIcon(star);
                   }
  }//end of if

if(e.getSource()==b6){
    Icon s1=b6.getIcon();
      if(b3.getIcon()==star){
        b3.setIcon(s1);
        b6.setIcon(star);
      } else if(b5.getIcon()==star){
                    b5.setIcon(s1);
                    b6.setIcon(star);
                   }
         else if(b9.getIcon()==star){
                    b9.setIcon(s1);
                    b6.setIcon(star);
                   }
         else if(b18.getIcon()==star){
                    b18.setIcon(s1);
                    b6.setIcon(star);
                   }
}//end of if

if(e.getSource()==b7){
    Icon s1=b7.getIcon();
      if(b4.getIcon()==star){
        b4.setIcon(s1);
        b7.setIcon(star);
      } else if(b8.getIcon()==star){
                    b8.setIcon(s1);
                    b7.setIcon(star);
                   }
        else if(b23.getIcon()==star){
                    b23.setIcon(s1);
                    b7.setIcon(star);
                   }
 }//end of if

   if(e.getSource()==b8){
    Icon s1=b8.getIcon();
      if(b7.getIcon()==star){
        b7.setIcon(s1);
        b8.setIcon(star);
      } else if(b5.getIcon()==star){
                    b5.setIcon(s1);
                    b8.setIcon(star);
                   }
         else if(b9.getIcon()==star){
                    b9.setIcon(s1);
                    b8.setIcon(star);
                   }
         else if(b24.getIcon()==star){
                    b24.setIcon(s1);
                    b8.setIcon(star);
                   }

  }//end of if


 if(e.getSource()==b9){
    Icon s1=b9.getIcon();
      if(b8.getIcon()==star){
        b8.setIcon(s1);
        b9.setIcon(star);
      } else if(b6.getIcon()==star){
                    b6.setIcon(s1);
                    b9.setIcon(star);
                   }
        else if(b22.getIcon()==star){
                    b22.setIcon(s1);
                    b9.setIcon(star);
                   }
        else if(b25.getIcon()==star){
                    b25.setIcon(s1);
                    b9.setIcon(star);
                   }
  }//end of if

  if(e.getSource()==b14){
    Icon s1 = b14.getIcon();
      if(b3.getIcon()==star){
        b3.setIcon(s1);
        b14.setIcon(star);
      } else if(b18.getIcon()==star){
                     b18.setIcon(s1);
                     b14.setIcon(star);
      }

  }//end of if

  if(e.getSource()==b18){
    Icon s1=b18.getIcon();
      if(b6.getIcon()==star){
        b6.setIcon(s1);
        b18.setIcon(star);
      } else if(b14.getIcon()==star){
                    b14.setIcon(s1);
                    b18.setIcon(star);
                   }
         else if(b22.getIcon()==star){
                    b22.setIcon(s1);
                    b18.setIcon(star);
                   }
  }//end of if

  if(e.getSource()==b22){
    Icon s1=b22.getIcon();
      if(b18.getIcon()==star){
        b18.setIcon(s1);
        b22.setIcon(star);
      } else if(b9.getIcon()==star){
                    b9.setIcon(s1);
                    b22.setIcon(star);
                   }
        else if(b26.getIcon()==star){
                    b26.setIcon(s1);
                    b22.setIcon(star);
                   }
  }//end of if

  if(e.getSource()==b23){
    Icon s1=b23.getIcon();
      if(b7.getIcon()==star){
        b7.setIcon(s1);
        b23.setIcon(star);
      } else if(b24.getIcon()==star){
                    b24.setIcon(s1);
                    b23.setIcon(star);
                   }
  }//end of if

  if(e.getSource()==b24){
    Icon s1=b24.getIcon();
      if(b8.getIcon()==star){
        b8.setIcon(s1);
        b24.setIcon(star);
      } else if(b23.getIcon()==star){
                    b23.setIcon(s1);
                    b24.setIcon(star);
                   }
        else if(b25.getIcon()==star){
                    b25.setIcon(s1);
                    b24.setIcon(star);
                   }
  }//end of if

  if(e.getSource()==b25){
    Icon s1=b25.getIcon();
      if(b9.getIcon()==star){
        b9.setIcon(s1);
        b25.setIcon(star);
      } else if(b24.getIcon()==star){
                    b24.setIcon(s1);
                    b25.setIcon(star);
                   }
        else if(b26.getIcon()==star){
                    b26.setIcon(s1);
                    b25.setIcon(star);
                   }
  }//end of if

  if(e.getSource()==b26){
    Icon s1=b26.getIcon();
      if(b22.getIcon()==star){
        b22.setIcon(s1);
        b26.setIcon(star);
      } else if(b25.getIcon()==star){
                    b25.setIcon(s1);
                    b26.setIcon(star);
                   }
  }//end of if
  
// changing to next puzzle using sample button
if(e.getSource()==sample){
Icon s1=sample.getIcon();
 if(s1==samicon4){
sample.setIcon(samicon1);
b1.setIcon(ic1);
b2.setIcon(ic2);
b3.setIcon(ic3);
b4.setIcon(ic4);
b5.setIcon(ic5);
b6.setIcon(ic6);
b7.setIcon(ic7);
b8.setIcon(ic8);
b9.setIcon(ic9);
b14.setIcon(black);
b18.setIcon(black);
b22.setIcon(black);
b23.setIcon(black);
b24.setIcon(black);
b25.setIcon(black);
b26.setIcon(black);
b14.setEnabled(false);b18.setEnabled(false);b22.setEnabled(false);b23.setEnabled(false);b24.setEnabled(false);b25.setEnabled(false);b26.setEnabled(false);
star=b9.getIcon();
starB.setIcon(ic0);
}//eof if

else if(s1==samicon1){
sample.setIcon(samicon2);
b1.setIcon(ic11);
b2.setIcon(ic12);
b3.setIcon(ic13);
b4.setIcon(ic14);
b5.setIcon(ic15);
b6.setIcon(ic16);
b7.setIcon(ic17);
b8.setIcon(ic18);
b9.setIcon(ic19);
b14.setIcon(black);
b18.setIcon(black);
b22.setIcon(black);
b23.setIcon(black);
b24.setIcon(black);
b25.setIcon(black);
b26.setIcon(black);
b14.setEnabled(false);b18.setEnabled(false);b22.setEnabled(false);b23.setEnabled(false);b24.setEnabled(false);b25.setEnabled(false);b26.setEnabled(false);
star=b6.getIcon();
starB.setIcon(ic10);
}//eof else

else if(s1==samicon2){
sample.setIcon(samicon3);
b1.setIcon(ic21);
b2.setIcon(ic22);
b3.setIcon(ic23);
b4.setIcon(ic24);
b5.setIcon(ic25);
b6.setIcon(ic26);
b7.setIcon(ic27);
b8.setIcon(ic28);
b9.setIcon(ic29);
b14.setIcon(black);
b18.setIcon(black);
b22.setIcon(black);
b23.setIcon(black);
b24.setIcon(black);
b25.setIcon(black);
b26.setIcon(black);
b14.setEnabled(false);b18.setEnabled(false);b22.setEnabled(false);b23.setEnabled(false);b24.setEnabled(false);b25.setEnabled(false);b26.setEnabled(false);
star=b6.getIcon();
starB.setIcon(ic20);
}//eof else

else if(s1==samicon3){
  sample.setIcon(samicon4);
  b1.setIcon(ic31);
  b2.setIcon(ic32);
  b3.setIcon(ic33);
  b4.setIcon(ic34);
  b5.setIcon(ic35);
  b6.setIcon(ic36);
  b7.setIcon(ic37);
  b8.setIcon(ic38);
  b9.setIcon(ic39);
  b14.setEnabled(false);b18.setEnabled(false);b22.setEnabled(false);b23.setEnabled(false);b24.setEnabled(false);b25.setEnabled(false);b26.setEnabled(false);
  star=b6.getIcon();
  starB.setIcon(ic30);
  }//eof else



}

//easy button
if(e.getSource()==bEasy){
  b1.setVisible(true);
  b1.setEnabled(true);
  b1.setIcon(ic1);
  b2.setVisible(true);
  b2.setEnabled(true);
  b2.setIcon(ic2);
  b3.setVisible(true);
  b3.setEnabled(true);
  b3.setIcon(ic3);
  b4.setVisible(true);
  b4.setEnabled(true);
  b4.setIcon(ic4);
  b5.setVisible(true);
  b5.setEnabled(true);
  b5.setIcon(ic5);
  b6.setVisible(true);
  b6.setEnabled(true);
  b6.setIcon(ic6);

  //setMedium
  b14.setVisible(false);
  b14.setEnabled(false);
  b14.setIcon(ic39);
  b18.setVisible(false);
  b18.setEnabled(false);
  b18.setIcon(ic10);
  b22.setVisible(false);
  b22.setEnabled(false);
  b22.setIcon(ic10);
  b23.setVisible(false);
  b23.setEnabled(false);
  b23.setIcon(ic16);
  b24.setVisible(false);
  b24.setEnabled(false);
  b24.setIcon(ic17);
  b25.setVisible(false);
  b25.setEnabled(false);
  b25.setIcon(ic18);
  b26.setVisible(false);
  b26.setEnabled(false);
  b26.setIcon(ic15);

  //setHard
  b51.setVisible(false);
  b51.setEnabled(false);
  b51.setIcon(ic39);
  b52.setVisible(false);
  b52.setEnabled(false);
  b52.setIcon(ic10);
  b53.setVisible(false);
  b53.setEnabled(false);
  b53.setIcon(ic10);
  b54.setVisible(false);
  b54.setEnabled(false);
  b54.setIcon(ic16);
  b55.setVisible(false);
  b55.setEnabled(false);
  b55.setIcon(ic17);
  b56.setVisible(false);
  b56.setEnabled(false);
  b56.setIcon(ic18);
  b57.setVisible(false);
  b57.setEnabled(false);
  b57.setIcon(ic15);
  b58.setVisible(false);
  b58.setEnabled(false);
  b58.setIcon(ic17);
  b59.setVisible(false);
  b59.setEnabled(false);
  b59.setIcon(ic18);
}

//medium button
if(e.getSource()==bMedium){
  b14.setVisible(true);
  b14.setEnabled(true);
  b14.setIcon(ic41);
  b18.setVisible(true);
  b18.setEnabled(true);
  b18.setIcon(ic42);
  b22.setVisible(true);
  b22.setEnabled(true);
  b22.setIcon(ic43);
  b23.setVisible(true);
  b23.setEnabled(true);
  b23.setIcon(ic44);
  b24.setVisible(true);
  b24.setEnabled(true);
  b24.setIcon(ic45);
  b25.setVisible(true);
  b25.setEnabled(true);
  b25.setIcon(ic46);
  b26.setVisible(true);
  b26.setEnabled(true);
  b26.setIcon(ic47);

    //setHard
  b51.setVisible(false);
  b51.setEnabled(false);
  b51.setIcon(ic39);
  b52.setVisible(false);
  b52.setEnabled(false);
  b52.setIcon(ic10);
  b53.setVisible(false);
  b53.setEnabled(false);
  b53.setIcon(ic10);
  b54.setVisible(false);
  b54.setEnabled(false);
  b54.setIcon(ic16);
  b55.setVisible(false);
  b55.setEnabled(false);
  b55.setIcon(ic17);
  b56.setVisible(false);
  b56.setEnabled(false);
  b56.setIcon(ic18);
  b57.setVisible(false);
  b57.setEnabled(false);
  b57.setIcon(ic15);
  b58.setVisible(false);
  b58.setEnabled(false);
  b58.setIcon(ic17);
  b59.setVisible(false);
  b59.setEnabled(false);
  b59.setIcon(ic18);

}
// hard button
if(e.getSource()==bHard){
  b14.setVisible(true);
  b14.setEnabled(true);
  b14.setIcon(ic41);
  b18.setVisible(true);
  b18.setEnabled(true);
  b18.setIcon(ic42);
  b22.setVisible(true);
  b22.setEnabled(true);
  b22.setIcon(ic43);
  b23.setVisible(true);
  b23.setEnabled(true);
  b23.setIcon(ic44);
  b24.setVisible(true);
  b24.setEnabled(true);
  b24.setIcon(ic45);
  b25.setVisible(true);
  b25.setEnabled(true);
  b25.setIcon(ic46);
  b26.setVisible(true);
  b26.setEnabled(true);
  b26.setIcon(ic47);

  b51.setVisible(true);
  b51.setEnabled(true);
  b51.setIcon(ic48);
  b52.setVisible(true);
  b52.setEnabled(true);
  b52.setIcon(ic49);
  b53.setVisible(true);
  b53.setEnabled(true);
  b53.setIcon(ic51);
  b54.setVisible(true);
  b54.setEnabled(true);
  b54.setIcon(ic52);
  b55.setVisible(true);
  b55.setEnabled(true);
  b55.setIcon(ic53);
  b56.setVisible(true);
  b56.setEnabled(true);
  b56.setIcon(ic54);
  b57.setVisible(true);
  b57.setEnabled(true);
  b57.setIcon(ic55);
  b58.setVisible(true);
  b58.setEnabled(true);
  b58.setIcon(ic56);
  b59.setVisible(true);
  b59.setEnabled(true);
  b59.setIcon(ic57);

}

}//end of actionPerformed



// main method to start puzzle
public static void main(String args[]){
new picpuzzle2();
}//end of main
}//end of class